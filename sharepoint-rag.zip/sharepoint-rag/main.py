import google.generativeai as genai
from decouple import config
from PIL import Image
import os


genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

if os.path.exists('./img1.webp'):
    print("exists")
else:
    print("doesnot exists")

model = genai.GenerativeModel('gemini-2.5-flash')


img=Image.open('./img1.webp')
response = model.generate_content(["Describe this image",img])
print(response.text)
