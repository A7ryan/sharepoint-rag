1. python -m venv venv

2. venv\Scripts\Activate

3. 