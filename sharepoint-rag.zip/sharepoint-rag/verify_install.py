try:
    import fitz
    import pptx
    import docx
    print("Imports Successful")
except Exception as e:
    print(f"Import Failed: {e}")
