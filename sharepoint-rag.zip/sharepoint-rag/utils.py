import os
import google.generativeai as genai
from decouple import config
from PIL import Image
import pandas as pd
from docx import Document
from pptx import Presentation
from duckduckgo_search import DDGS
import io
import fitz
from pptx.enum.shapes import MSO_SHAPE_TYPE

# Configure Gemini
# Try getting API key from environment variable, otherwise from .env if loaded via separate mechanism or main.py logic
# Ideally decouple's config handles .env automatically if python-decouple is used correctly.
try:
    API_KEY = config("GEMINI_API_KEY")
except:
    API_KEY = os.getenv("GEMINI_API_KEY")

if API_KEY:
    genai.configure(api_key=API_KEY)

model = genai.GenerativeModel('gemini-2.5-flash')

def describe_image(image_bytes):
    try:
        image = Image.open(io.BytesIO(image_bytes))
        prompt = "Describe this image in detail. Extract text if present. If it's a diagram, explain the flow."
        response = model.generate_content([prompt, image])
        return response.text
    except Exception as e:
        return f"[Error describing image: {e}]"

def extract_text_from_file(uploaded_file):
    """
    Extracts text from various file formats.
    Returns the extracted text as a string.
    """
    file_type = uploaded_file.type
    file_name = uploaded_file.name.lower()
    
    try:
        if "image" in file_type or file_name.endswith(('.png', '.jpg', '.jpeg', '.webp')):
            image = Image.open(uploaded_file)
            # Use Gemini to describe the image/extract text including diagrams
            prompt = "Extract all text from this image. If it's a diagram, describe the flow and connections in detail. If it's a document, transcribe it."
            response = model.generate_content([prompt, image])
            return response.text

        elif "pdf" in file_type or file_name.endswith('.pdf'):
            file_bytes = uploaded_file.getvalue()
            doc = fitz.open(stream=file_bytes, filetype="pdf")
            full_text = []
            for page_num, page in enumerate(doc):
                text = page.get_text()
                full_text.append(text)
                
                # Images
                image_list = page.get_images()
                for img_index, img in enumerate(image_list):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    if len(image_bytes) > 2000: # Filter small icons
                        desc = describe_image(image_bytes)
                        full_text.append(f"\n[Image Description on Page {page_num+1}]: {desc}\n")
            
            return "\n".join(full_text)

        elif "word" in file_type or file_name.endswith(('.docx', '.doc')):
            doc = Document(uploaded_file)
            full_text = []
            for para in doc.paragraphs:
                full_text.append(para.text)
            
            # Extract images from relationships (best effort for DOCX)
            try:
                for rel in doc.part.rels.values():
                    if "image" in rel.target_ref:
                        if hasattr(rel, "target_part") and hasattr(rel.target_part, "blob"):
                            desc = describe_image(rel.target_part.blob)
                            full_text.append(f"\n[Image Description in Document]: {desc}\n")
            except Exception as e:
                full_text.append(f"[Error extracting images from DOCX: {e}]")
                
            return '\n'.join(full_text)

        elif "sheet" in file_type or "excel" in file_type or file_name.endswith(('.xlsx', '.xls')):
            df = pd.read_excel(uploaded_file)
            return df.to_string()

        elif "presentation" in file_type or "powerpoint" in file_type or file_name.endswith(('.pptx', '.ppt')):
            prs = Presentation(uploaded_file)
            full_text = []
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text"):
                        full_text.append(shape.text)
                    
                    if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                        try:
                            image = shape.image
                            image_bytes = image.blob
                            desc = describe_image(image_bytes)
                            full_text.append(f"\n[Image Description]: {desc}\n")
                        except Exception as e:
                            pass
            return '\n'.join(full_text)

        elif "text" in file_type or file_name.endswith('.txt'):
            return str(uploaded_file.read(), "utf-8")

        else:
            return "Unsupported file format."

    except Exception as e:
        return f"Error extracting text: {str(e)}"

def perform_web_search(query_text):
    """
    1. Summarize the query_text if it's too long to be a search query.
    2. Search the web.
    3. Synthesize the results using Gemini to answer/explain based on the original data.
    """
    
    # 1. Create a search query
    search_prompt = f"Based on the following text, generate a concise web search query to find more information or context about the main topics:\n\n{query_text[:2000]}"
    try:
        search_query_response = model.generate_content(search_prompt)
        search_query = search_query_response.text.strip()
    except Exception as e:
        search_query = query_text[:200] # Fallback
    
    # 2. Perform Search
    results_text = ""
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(search_query, max_results=5))
            for res in results:
                results_text += f"\nTitle: {res['title']}\nLink: {res['href']}\nSnippet: {res['body']}\n"
    except Exception as e:
        return f"Search failed: {str(e)}"

    # 3. Synthesize
    synthesis_prompt = f"""
    You are a helpful assistant. 
    Here is the context extracted from a file:
    {query_text[:4000]}... (truncated)

    Here are web search results for "{search_query}":
    {results_text}

    Please provide a summary explaining the file's content with additional context from the web. 
    Cite the links provided in the search results.
    """
    
    try:
        synthesis_response = model.generate_content(synthesis_prompt)
        return synthesis_response.text
    except Exception as e:
        return f"Synthesis failed: {str(e)}"
