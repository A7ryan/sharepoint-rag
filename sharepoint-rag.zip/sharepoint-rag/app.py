import streamlit as st
import os
from utils import extract_text_from_file, perform_web_search

st.set_page_config(page_title="Smart File Extractor & Search", page_icon="🔍")

st.title("📄 Smart File Extractor & Web Search")
st.markdown("Upload a file (Image, PDF, DOCX, PPTX, Excel, Text) to extract content or find more info on the web.")

# File Uploader
uploaded_file = st.file_uploader("Choose a file", type=['png', 'jpg', 'jpeg', 'webp', 'pdf', 'txt', 'docx', 'doc', 'pptx', 'ppt', 'xlsx', 'xls'])

if uploaded_file is not None:
    st.info(f"File '{uploaded_file.name}' uploaded successfully.")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Text Extraction"):
            with st.spinner("Extracting text..."):
                extracted_text = extract_text_from_file(uploaded_file)
                st.session_state['extracted_text'] = extracted_text
                st.session_state['last_file'] = uploaded_file.name
                
    with col2:
        if st.button("Web Search"):
            with st.spinner("Analyzing and Searching..."):
                # Ensure text is extracted
                if 'extracted_text' in st.session_state and st.session_state.get('last_file') == uploaded_file.name:
                    text_to_search = st.session_state['extracted_text']
                else:
                    text_to_search = extract_text_from_file(uploaded_file)
                    st.session_state['extracted_text'] = text_to_search
                    st.session_state['last_file'] = uploaded_file.name
                
                # Perform search
                search_results = perform_web_search(text_to_search)
                st.session_state['search_results'] = search_results

    # Display Results
    if 'extracted_text' in st.session_state and st.session_state.get('last_file') == uploaded_file.name:
        with st.expander("Extracted Text", expanded=True):
            st.write(st.session_state['extracted_text'])

    if 'search_results' in st.session_state and st.session_state.get('last_file') == uploaded_file.name:
        st.divider()
        st.subheader("🌐 Web Search Insights")
        st.markdown(st.session_state['search_results'])

else:
    # Clear state if no file
    if 'extracted_text' in st.session_state:
        del st.session_state['extracted_text']
    if 'search_results' in st.session_state:
        del st.session_state['search_results']
